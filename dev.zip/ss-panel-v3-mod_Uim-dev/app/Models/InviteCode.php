<?php

namespace App\Models;

/**
 * InviteCode Model
 */

class InviteCode extends Model
{
    protected $connection = "default";
    protected $table = "ss_invite_code";
}
